import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  // life cycle
  title = 'angular-example-two';
  showChild: boolean = false;

  oddNumber : number[] = [];
  evenNumber : number[] = [];

  changeShow() {
    this.showChild = !this.showChild;
  }

  onIntervalEmitted(numberEmitted: number){
    if(numberEmitted % 2 === 1)
      this.oddNumber.push(numberEmitted);
    else
      this.evenNumber.push(numberEmitted);
  }

  
}
