import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ComponentCommunicationExComponent } from './components/component-communication-ex/component-communication-ex.component';
import { LifeCycleComponent } from './components/life-cycle/life-cycle.component';
import { InputComponent } from './components/component-communication-ex/input/input.component';
import { OutputComponent } from './components/component-communication-ex/output/output.component';
import { LocalVariableComponent } from './components/component-communication-ex/local-variable/local-variable.component';
import { ViewChildComponent } from './components/component-communication-ex/view-child/view-child.component';
import { ServiceExComponent } from './components/service-ex/service-ex.component';
import { SubOneComponent } from './components/service-ex/sub-one/sub-one.component';
import { SubTwoComponent } from './components/service-ex/sub-two/sub-two.component';
import { HttpExComponent } from './components/http-ex/http-ex.component';
import { ObservablesComponent } from './components/http-ex/observables/observables.component';
import { HttpComponent } from './components/http-ex/http/http.component';
import { HttpClientModule } from '@angular/common/http';
import { NamesService } from './services/names.service';
import { GameControlComponent } from './components/game-control/game-control.component';
import { OddComponent } from './components/odd/odd.component';
import { EvenComponent } from './components/even/even.component';
import { ActiveUserComponent } from './components/active-user/active-user.component';
import { InactiveUserComponent } from './components/inactive-user/inactive-user.component';

@NgModule({
  declarations: [
    AppComponent,
    ComponentCommunicationExComponent,
    LifeCycleComponent,
    InputComponent,
    OutputComponent,
    LocalVariableComponent,
    ViewChildComponent,
    ServiceExComponent,
    SubOneComponent,
    SubTwoComponent,
    HttpExComponent,
    ObservablesComponent,
    HttpComponent,
    GameControlComponent,
    OddComponent,
    EvenComponent,
    ActiveUserComponent,
    InactiveUserComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [NamesService],
  bootstrap: [AppComponent]
})
export class AppModule { }
