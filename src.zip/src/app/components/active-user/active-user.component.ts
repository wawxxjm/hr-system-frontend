import { UserServiceService } from './../../services/user-service.service';
import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'app-active-user',
  templateUrl: './active-user.component.html',
  styleUrls: ['./active-user.component.css']
})
export class ActiveUserComponent implements OnInit {
  activeUsers : string[];

  constructor(private userServiceService : UserServiceService) { 
  }
  ngOnInit(): void {
    this.activeUsers = this.userServiceService.getActiveUsers();
  }

  setToInactive(index : number){
    this.userServiceService.setInActive(index, true);
  }


}
