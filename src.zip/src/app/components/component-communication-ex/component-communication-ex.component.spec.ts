import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ComponentCommunicationExComponent } from './component-communication-ex.component';

describe('ComponentCommunicationExComponent', () => {
  let component: ComponentCommunicationExComponent;
  let fixture: ComponentFixture<ComponentCommunicationExComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ComponentCommunicationExComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ComponentCommunicationExComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
