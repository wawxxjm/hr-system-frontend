import { Component, OnInit, ViewChild } from '@angular/core';
import { ViewChildComponent } from './view-child/view-child.component';

@Component({
  selector: 'app-component-communication-ex',
  templateUrl: './component-communication-ex.component.html',
  styleUrls: ['./component-communication-ex.component.css']
})

export class ComponentCommunicationExComponent implements OnInit {

  @ViewChild(ViewChildComponent)
  private component: ViewChildComponent;
    
  names: string[] = ["Landon", "Fan", "Zack"];
  apple = 0;
  banana = 0;

  constructor() { }

  ngOnInit(): void {
  }

  onPick(apple: boolean) {
    apple ? this.apple++ : this.banana++;
  }

  increase() {
      
  }

  decrease() {
    this.component.decrease();
  }

}
