import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-output',
  templateUrl: './output.component.html',
  styleUrls: ['./output.component.css']
})
export class OutputComponent implements OnInit {

  @Input() name;
  @Output() picked = new EventEmitter<boolean>();
  didPick: boolean = false;

  constructor() { }

  ngOnInit(): void {
  }

  pick(apple: boolean) {
    this.picked.emit(apple);
    this.didPick = true;
  }

}
