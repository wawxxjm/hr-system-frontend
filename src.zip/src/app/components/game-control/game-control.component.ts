import { Component, EventEmitter, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-game-control',
  templateUrl: './game-control.component.html',
  styleUrls: ['./game-control.component.css']
})
export class GameControlComponent implements OnInit {
  @Output() intervalEmitted = new EventEmitter<number>();
  interval;
  second : number = 1;


  constructor() { }

  ngOnInit(): void {
    
  }

  startGame(){
    this.interval = setInterval(() => {
      this.intervalEmitted.emit(this.second);
      this.second++;
    }, 1000)
  }

  endGame(){
    clearInterval(this.interval);
  }

}
