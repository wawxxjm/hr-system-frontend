import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-http-ex',
  templateUrl: './http-ex.component.html',
  styleUrls: ['./http-ex.component.css']
})
export class HttpExComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
