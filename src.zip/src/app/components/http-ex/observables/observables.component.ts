import { Component, OnInit } from '@angular/core';
import { Observable, Subscriber, Subscription } from 'rxjs';

@Component({
  selector: 'app-observables',
  templateUrl: './observables.component.html',
  styleUrls: ['./observables.component.css']
})
export class ObservablesComponent implements OnInit {

  subscribe(landon) {
    landon.next("Landon");
    landon.next("Fan");
    landon.next("Zack");
    landon.error("This is an error test");
    landon.complete();
  }

  test: Observable<any> = new Observable<any>(this.subscribe);
  subscriber: Subscription;

  constructor() { }

  ngOnInit(): void {
  }

  startSubsribe() {
    console.log(this.test);
    this.subscriber = this.test.subscribe(
      (success) => { console.log(success) },
      error => console.log(error),
      () => console.log("Observable is complete")
    );
  }

  endSubscribe() {
    this.subscriber.unsubscribe();
  }

}
