import { Component, OnInit, ViewChild } from '@angular/core';
import { NamesService } from '../../services/names.service';
import { SubOneComponent } from './sub-one/sub-one.component';
import { SubTwoComponent } from './sub-two/sub-two.component';

@Component({
  selector: 'app-service-ex',
  templateUrl: './service-ex.component.html',
  styleUrls: ['./service-ex.component.css']
})
export class ServiceExComponent implements OnInit {

  @ViewChild(SubOneComponent)
  subOne: SubOneComponent;

  @ViewChild(SubTwoComponent)
  subTwo: SubTwoComponent;

  constructor(public namesService: NamesService) {}

  ngOnInit(): void { }
  
  changeName(name: string) {
    this.namesService.setName(name);
    this.subOne.refreshName();
    this.subTwo.refreshName();
  }

}
