import { Component, OnInit } from '@angular/core';
import { NamesService } from '../../../services/names.service';

@Component({
  selector: 'app-sub-one',
  templateUrl: './sub-one.component.html',
  styleUrls: ['./sub-one.component.css']
})
export class SubOneComponent implements OnInit {

  name: string;

  constructor(public namesService: NamesService) { }

  ngOnInit(): void {
    this.name = this.namesService.getName();
  }

  refreshName() {
    this.name = this.namesService.getName();
  }

}
