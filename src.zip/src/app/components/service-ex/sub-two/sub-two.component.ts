import { Component, OnInit } from '@angular/core';
import { NamesService } from '../../../services/names.service';

@Component({
  selector: 'app-sub-two',
  templateUrl: './sub-two.component.html',
  styleUrls: ['./sub-two.component.css']
})
export class SubTwoComponent implements OnInit {

  name: string;

  constructor(public namesService: NamesService) { }

  ngOnInit(): void {
    this.name = this.namesService.getName();
  }

  refreshName() {
    this.name = this.namesService.getName();
  }

}
