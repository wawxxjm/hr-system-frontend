import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NamesService {

  name: string;

  constructor() {
    this.name = "Landon";
  }

  getName() {
    return this.name;
  }

  setName(name: string | null) {
    this.name = name;
  }

}
