import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {
  constructor() { }

  activeUsers = ['Chris', 'Anna', 'Fan'];
  inactiveUsers = ['Manu', 'Max', 'Landon'];

  getActiveUsers(){
    return this.activeUsers;
  }

  getInactiveUsers(){
    return this.inactiveUsers;
  }

  setInActive(index : number, active : boolean){
      this.inactiveUsers.push(this.activeUsers[index]);
      this.activeUsers.splice(index, 1);
  }

  setActive(index : number, active : boolean){
      this.activeUsers.push(this.inactiveUsers[index]);
      this.inactiveUsers.splice(index, 1);
  }
}
